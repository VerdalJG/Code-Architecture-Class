#include "Stair.h"

Stair::Stair()
{
}

Stair::~Stair()
{
}
