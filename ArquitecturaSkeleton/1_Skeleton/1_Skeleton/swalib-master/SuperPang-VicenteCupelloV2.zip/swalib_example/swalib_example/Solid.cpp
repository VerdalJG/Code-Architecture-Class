#include "Solid.h"
#include "WorldManager.h"
#include "RenderComponent.h"

Solid::Solid()
{
	
}

Solid::~Solid()
{
}

void Solid::OnCollide(Entity* other)
{
}
