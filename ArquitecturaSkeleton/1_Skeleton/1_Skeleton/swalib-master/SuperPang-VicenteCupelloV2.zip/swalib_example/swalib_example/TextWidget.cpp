#include "TextWidget.h"

TextWidget::TextWidget()
{
}

TextWidget::~TextWidget()
{
}
