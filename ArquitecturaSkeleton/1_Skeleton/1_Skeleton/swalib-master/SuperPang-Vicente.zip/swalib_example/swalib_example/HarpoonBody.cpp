#include "HarpoonBody.h"
#include "MovementComponent.h"
#include "BoxCollisionComponent.h"

HarpoonBody::HarpoonBody()
{
}

HarpoonBody::~HarpoonBody()
{
}

void HarpoonBody::BeginPlay()
{
	movementComponent = GetComponent<MovementComponent>();
	collisionComponent = GetComponent<BoxCollisionComponent>();
}

void HarpoonBody::Tick(float deltaTime)
{
	Actor::Tick(deltaTime);
}

void HarpoonBody::OnCollide(Entity* other)
{
	if (other->GetName() == ("TopWall")) // Returns 0 if equal
	{
		ResetBody();
	}
}

void HarpoonBody::ResetBody()
{
	SetWorldPosition(vec2(800, 800));
	SetWorldScale(vec2(1, 1));
	movementComponent->SetVelocity(vec2(0,0));
}
