#include "MovementMessage.h"

MovementMessage::MovementMessage(vec2 newPosition)
{
	this->newPosition = newPosition;
}
