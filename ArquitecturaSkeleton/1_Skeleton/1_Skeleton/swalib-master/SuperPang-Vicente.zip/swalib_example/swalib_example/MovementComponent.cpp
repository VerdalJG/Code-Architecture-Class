#include "MovementComponent.h"
#include "MovementMessage.h"
#include "CollisionMessage.h"
#include "Entity.h"


MovementComponent::MovementComponent()
{
	
}

void MovementComponent::Tick(float deltaTime)
{
	vec2 newPosition = worldPosition + velocity * deltaTime;
	worldPosition = newPosition;
	previousMovement = velocity * deltaTime;

	//Messages
	owner->SetWorldPosition(worldPosition);
}


void MovementComponent::ReceiveMessage(Message* message)
{
	CollisionMessage* collisionMessage = dynamic_cast<CollisionMessage*>(message);
	if (collisionMessage)
	{
		// Negate previous movement, velocity is handled on a case by case basis
		worldPosition += collisionMessage->normal * collisionMessage->depth;
	}

	MovementMessage* movementMessage = dynamic_cast<MovementMessage*>(message);
	if (movementMessage)
	{
		worldPosition = movementMessage->newPosition;
	}
}
