#pragma once
#include "Globals.h"
#include "Actor.h"

class MovementComponent;
class Harpoon;
class BoxCollisionComponent;

class Player : public Actor
{
public:
	Player();
	virtual ~Player() override;

	virtual void BeginPlay() override;
	virtual void Tick(float deltaTime) override;
	virtual void OnCollide(Entity* other);
	void Move(vec2 direction);
	void ShootHarpoon();

private:
	Harpoon* harpoon;
	MovementComponent* movementComponent;
	BoxCollisionComponent* collisionComponent;
	const float acceleration = 40.0f;
	const float maxWalkingVelocity = 100.0f;
	const float maxFallSpeed = 100.0f;
};

