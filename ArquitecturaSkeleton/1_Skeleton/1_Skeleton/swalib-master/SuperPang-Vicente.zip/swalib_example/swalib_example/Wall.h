#pragma once
#include "Solid.h"

class Wall : public Solid
{
public:
	Wall();
	virtual ~Wall() override;
};

