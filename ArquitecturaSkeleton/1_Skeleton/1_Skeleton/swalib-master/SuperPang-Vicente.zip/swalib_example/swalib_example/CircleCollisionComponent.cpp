#include "CircleCollisionComponent.h"
#include "World.h"
#include "Entity.h"
#include "CollisionMessage.h"
#include "BoxCollisionComponent.h"


CircleCollisionComponent::CircleCollisionComponent(float radius)
{
	this->radius = radius;
	type = ColliderType::Circle;
}

CircleCollisionComponent::~CircleCollisionComponent()
{
}

bool CircleCollisionComponent::CircleBoxCollisionCheck(CollisionComponent* otherCollider, vec2& collisionNormal, float& depthOfIntersection)
{
	BoxCollisionComponent* otherComponent = dynamic_cast<BoxCollisionComponent*>(otherCollider);

	vec2 otherPosition = otherComponent->GetWorldPosition();
	vec2 otherHalfExtents = otherComponent->GetHalfExtents();

	// Calculate the extents of the box (left, right, top, bottom edges)
	float leftEdge = otherPosition.x - otherHalfExtents.x;
	float rightEdge = otherPosition.x + otherHalfExtents.x;
	float topEdge = otherPosition.y + otherHalfExtents.y;
	float bottomEdge = otherPosition.y - otherHalfExtents.y;

	// Calculate the distances from the circle's center to the edges of the box
	float distanceToLeft = worldPosition.x - leftEdge;
	float distanceToRight = rightEdge - worldPosition.x;
	float distanceToTop = topEdge - worldPosition.y;
	float distanceToBottom = worldPosition.y - bottomEdge;
	
	float minDistanceX = min(distanceToLeft, distanceToRight);
	float minDistanceY = min(distanceToTop, distanceToBottom);
	float minDistance = min(minDistanceX, minDistanceY);

	if (minDistance == distanceToLeft)
	{
		collisionNormal = vec2(-1.0f, 0.0f);
		depthOfIntersection = radius - distanceToLeft;
	}
	if (minDistance == distanceToRight)
	{
		collisionNormal = vec2(1.0f, 0.0f);
		depthOfIntersection = radius - distanceToRight;
	}
	if (minDistance == distanceToTop)
	{
		collisionNormal = vec2(0.0f, 1.0f);
		depthOfIntersection = radius - distanceToTop;
	}
	if (minDistance == distanceToBottom)
	{
		collisionNormal = vec2(0.0f, -1.0f);
		depthOfIntersection = radius - distanceToBottom;
	}

	return depthOfIntersection >= 0;
}

bool CircleCollisionComponent::CircleCircleCollisionCheck(CollisionComponent* otherCollider, vec2& collisionNormal, float& depthOfIntersection)
{
	CircleCollisionComponent* otherComponent = dynamic_cast<CircleCollisionComponent*>(otherCollider);
	if (otherComponent)
	{
		float worldRadius = radius * max(owner->GetWorldScale().x, owner->GetWorldScale().y);
		float otherWorldRadius = otherComponent->GetRadius() * max(otherComponent->owner->GetWorldScale().x, otherComponent->owner->GetWorldScale().y);

		float limitSquared = (radius + otherWorldRadius) * (radius + otherWorldRadius);
		if (vlen2(worldPosition - otherComponent->GetWorldPosition()) <= limitSquared)
		{
			collisionNormal = vnorm(otherComponent->GetWorldPosition() - worldPosition);
			depthOfIntersection = radius + otherWorldRadius - sqrt(vlen2(worldPosition - otherComponent->GetWorldPosition()));
			return true;
		}
	}

	return false;
}