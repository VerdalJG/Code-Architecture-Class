#include "Player.h"
#include "MovementComponent.h"
#include "Solid.h"
#include "Harpoon.h"
#include "World.h"
#include "BoxCollisionComponent.h"


Player::Player() :
	movementComponent(nullptr)
{
}

Player::~Player()
{
}

void Player::BeginPlay()
{
	movementComponent = GetComponent<MovementComponent>();
	collisionComponent = GetComponent<BoxCollisionComponent>();
	harpoon = GetWorld()->FindActor<Harpoon>();
}

void Player::Tick(float deltaTime)
{
	Actor::Tick(deltaTime);
}

void Player::OnCollide(Entity* other)
{
	Solid* wall = dynamic_cast<Solid*>(other);
	if (wall)
	{
		movementComponent->SetVelocity(vec2());
	}
}

void Player::Move(vec2 direction)
{
	vec2 currentVelocity = movementComponent->GetVelocity();
	if (direction == vec2())
	{
		currentVelocity = direction;
		movementComponent->SetVelocity(currentVelocity);
	}
	else
	{
		currentVelocity += direction * acceleration;
		currentVelocity = vec2clamp(currentVelocity, vec2(-maxWalkingVelocity, -maxFallSpeed), vec2(maxWalkingVelocity, maxFallSpeed));
		movementComponent->SetVelocity(currentVelocity);
	}
}

void Player::ShootHarpoon()
{
	if (!harpoon->IsOnScreen())
	{
		vec2 floorPosition = vec2(worldPosition.x, worldPosition.y - collisionComponent->GetHalfExtents().y);
		harpoon->Fire(floorPosition);
	}
}
