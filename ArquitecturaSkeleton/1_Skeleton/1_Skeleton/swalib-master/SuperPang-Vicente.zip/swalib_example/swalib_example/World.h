#pragma once
#include "Globals.h"

class Entity;
class Actor;
class Solid;
class Sprite;
class TimeManager; 
class Background;
class Widget;
class Player;


enum class CollisionLayer
{
	Default,
	Player,
	Balls,
	Environment,
	Bullet,
	NumLayers // This helps track the total count
};

class World
{
public:
	World();
	void BeginPlay();
	void InitializeCollisionMatrix();
	void Terminate();
	void AddActor(Actor* actor);
	void RemoveEntity(Actor* actor);
	bool ShouldCollide(CollisionLayer layer1, CollisionLayer layer2);

	void AddSolid(Solid* solid);
	void RemoveSolid(Solid* solid);

	void AddWidget(Widget* widget);
	void RemoveWidget(Widget* widget);

	void Tick(float deltaTime);
	void ProcessInputs();

private:
	std::vector<Solid*> solids;
	std::vector<Actor*> actors;
	std::vector<Entity*> entities;
	Background* background;
	Player* player = nullptr;

	// Define the matrix using a 2D array of booleans
	bool collisionMatrix[static_cast<int>(CollisionLayer::NumLayers)][static_cast<int>(CollisionLayer::NumLayers)];

public:
	std::vector<Entity*> GetEntities() { return entities; }
	void SetPlayer(Player* newPlayer) { player = newPlayer; }
	Background* GetBackground() { return background; }
	void SetBackground(Background* newBackground);

	template<typename T>
	T* FindActor()
	{
		for (Actor* actor : actors)
		{
			if (T* derivedActor = dynamic_cast<T*>(actor))
			{
				return derivedActor;
			}
		}
		return nullptr;
	}
};

