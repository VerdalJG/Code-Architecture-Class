#pragma once
#include "Component.h"
class AnimationComponent : public Component
{
};

