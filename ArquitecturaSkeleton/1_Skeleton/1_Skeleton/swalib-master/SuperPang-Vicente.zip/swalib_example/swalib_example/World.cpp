#include "World.h"
#include "TimerManager.h"
#include "Sprite.h"
#include "RenderManager.h"
#include "Entity.h"
#include "Background.h"
#include "Widget.h"
#include "InputManager.h"
#include "UIManager.h"
#include "Actor.h"
#include "Solid.h"
#include "Player.h"


World::World()
{
	background = new Background();
}

void World::BeginPlay()
{
	InitializeCollisionMatrix();
	for (Actor* actor : actors)
	{
		actor->BeginPlay();
	}
}

void World::InitializeCollisionMatrix()
{
	for (int i = 0; i < static_cast<int>(CollisionLayer::NumLayers); ++i) 
	{
		for (int j = 0; j < static_cast<int>(CollisionLayer::NumLayers); ++j) 
		{
			collisionMatrix[i][j] = false; // Default to no collision
		}
	}

	// Define specific layer interactions
	collisionMatrix[static_cast<int>(CollisionLayer::Default)][static_cast<int>(CollisionLayer::Default)] = true;
	collisionMatrix[static_cast<int>(CollisionLayer::Default)][static_cast<int>(CollisionLayer::Player)] = true;
	collisionMatrix[static_cast<int>(CollisionLayer::Default)][static_cast<int>(CollisionLayer::Environment)] = true;
	collisionMatrix[static_cast<int>(CollisionLayer::Default)][static_cast<int>(CollisionLayer::Bullet)] = true;
	collisionMatrix[static_cast<int>(CollisionLayer::Default)][static_cast<int>(CollisionLayer::Balls)] = true;

	collisionMatrix[static_cast<int>(CollisionLayer::Player)][static_cast<int>(CollisionLayer::Balls)] = true;
	collisionMatrix[static_cast<int>(CollisionLayer::Player)][static_cast<int>(CollisionLayer::Environment)] = true;

	collisionMatrix[static_cast<int>(CollisionLayer::Balls)][static_cast<int>(CollisionLayer::Player)] = true;
	collisionMatrix[static_cast<int>(CollisionLayer::Balls)][static_cast<int>(CollisionLayer::Environment)] = true;
	collisionMatrix[static_cast<int>(CollisionLayer::Balls)][static_cast<int>(CollisionLayer::Bullet)] = true;
	collisionMatrix[static_cast<int>(CollisionLayer::Balls)][static_cast<int>(CollisionLayer::Balls)] = true;

	collisionMatrix[static_cast<int>(CollisionLayer::Environment)][static_cast<int>(CollisionLayer::Player)] = true;
	collisionMatrix[static_cast<int>(CollisionLayer::Environment)][static_cast<int>(CollisionLayer::Balls)] = true;
	collisionMatrix[static_cast<int>(CollisionLayer::Environment)][static_cast<int>(CollisionLayer::Bullet)] = true;

	collisionMatrix[static_cast<int>(CollisionLayer::Bullet)][static_cast<int>(CollisionLayer::Balls)] = true;
	collisionMatrix[static_cast<int>(CollisionLayer::Bullet)][static_cast<int>(CollisionLayer::Environment)] = true;
}

// Check if two layers should collide
bool World::ShouldCollide(CollisionLayer layer1, CollisionLayer layer2) 
{
	return collisionMatrix[static_cast<int>(layer1)][static_cast<int>(layer2)];
}

void World::Terminate()
{
	if (background)
	{
		delete(background);
	}
	for (Entity* entity : entities)
	{
		delete(entity);
	}

	UIManager::GetInstance().ResetUI();
}

void World::AddActor(Actor* actor)
{
	if (actor)
	{
		actors.push_back(actor);
		entities.push_back(actor);
		RenderEngine::GetInstance().RegisterEntity(actor);
	}
}

void World::RemoveEntity(Actor* actor)
{
	if (actor)
	{
		actors.erase(std::remove(actors.begin(), actors.end(), actor), actors.end());
		entities.erase(std::remove(entities.begin(), entities.end(), actor), entities.end());
		RenderEngine::GetInstance().RemoveEntity(actor);
		delete(actor);
	}
}

void World::AddSolid(Solid* solid)
{
	if (solid)
	{
		solids.push_back(solid);
		entities.push_back(solid);
		RenderEngine::GetInstance().RegisterEntity(solid);
	}
}

void World::RemoveSolid(Solid* solid)
{
	if (solid)
	{
		solids.erase(std::remove(solids.begin(), solids.end(), solid), solids.end());
		entities.erase(std::remove(entities.begin(), entities.end(), solid), entities.end());
		RenderEngine::GetInstance().RemoveEntity(solid);
		delete(solid);
	}
}

void World::AddWidget(Widget* widget)
{
	if (widget)
	{
		UIManager::GetInstance().AddWidget(widget);
	}
}

void World::RemoveWidget(Widget* widget)
{
	if (widget)
	{
		UIManager::GetInstance().RemoveWidget(widget);
	}
}

void World::Tick(float deltaTime)
{
	for (Actor* actor : actors)
	{
		actor->Tick(deltaTime);
	}
}

void World::ProcessInputs()
{
	// Get the input manager instance
	InputManager& inputManager = InputManager::GetInstance();

	// Phase 1: Handle UI input
	if (UIManager::GetInstance().IsActive())  // Only if UI is active
	{
		if (inputManager.UIMovingUp())
		{
			UIManager::GetInstance().NavigateUp();
		}
		else if (inputManager.UIMovingDown())
		{
			UIManager::GetInstance().NavigateDown();
		}
		else if (inputManager.IsConfirming())
		{
			UIManager::GetInstance().Confirm();
		}
		// Return early to prevent processing game input while UI is active.
		return;
	}

	// Phase 2: Handle Game input (if UI didn't process the input)

	// Movement
	if (inputManager.IsMovingUp())
	{
		player->Move(vec2(0.0f,1.0f));
	}
	else if (inputManager.IsMovingDown())
	{
		player->Move(vec2(0.0f, -1.0f));
	}
	else if (inputManager.IsMovingLeft())
	{
		player->Move(vec2(-1.0f, 0.0f));
	}
	else if (inputManager.IsMovingRight())
	{
		player->Move(vec2(1.0f, 0.0f));
	}
	else
	{
		player->Move(vec2());
	}

	// Shooting
	if (inputManager.IsShooting())
	{
		player->ShootHarpoon();
	}
}

void World::SetBackground(Background* newBackground)
{
	if (background)
	{
		delete(background);
	}
	background = newBackground;
}
