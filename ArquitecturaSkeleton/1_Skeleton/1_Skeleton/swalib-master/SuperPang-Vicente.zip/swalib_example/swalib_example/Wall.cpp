#include "Wall.h"
#include "RenderComponent.h"
#include "CollisionComponent.h"
#include "BoxCollisionComponent.h"

Wall::Wall()
{
	
}

Wall::~Wall()
{
}
