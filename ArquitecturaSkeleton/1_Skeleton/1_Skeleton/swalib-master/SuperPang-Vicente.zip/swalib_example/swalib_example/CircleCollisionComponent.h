#pragma once
#include "CollisionComponent.h"

class CircleCollisionComponent : public CollisionComponent
{
public:
	CircleCollisionComponent(float radius);
	virtual ~CircleCollisionComponent() override;

	virtual bool CircleBoxCollisionCheck(CollisionComponent* otherCollider, vec2& collisionNormal, float& depthOfIntersection) override;
	virtual bool CircleCircleCollisionCheck(CollisionComponent* otherCollider, vec2& collisionNormal, float& depthOfIntersection) override;

private:
	float radius;

public:
	float GetRadius() { return radius; }
	void SetRadius(float newRadius) { radius = newRadius; }
};

