# swalib
C/C++ code library for simple 2D games, Windows &amp; OS X (and probably Linux), used for teaching Software Architecture for games
