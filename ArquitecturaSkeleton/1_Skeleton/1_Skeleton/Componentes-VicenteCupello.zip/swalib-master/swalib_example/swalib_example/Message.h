#pragma once
#include "Globals.h"

class Message
{
public:
	virtual ~Message() = default;
};

