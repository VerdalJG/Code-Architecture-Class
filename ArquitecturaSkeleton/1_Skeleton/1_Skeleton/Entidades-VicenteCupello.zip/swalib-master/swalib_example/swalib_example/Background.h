#pragma once
#include "Globals.h"
class Sprite;

class Background
{
public:
	Background();
	~Background();

	Sprite* sprite;
};

