#pragma once

class Sprite;

class Background
{
public:
	Background();
	~Background();

	Sprite* sprite;
};

